/*
 * package JavaDive.dao.board;
 * 
 * import java.sql.Connection; import java.sql.PreparedStatement;
 * 
 * import JavaDive.dto.board.BoardDto;
 * 
 * public class BoardDao {
 * 
 * private Connection connection; //연결준비 //
 * 
 * public void setConnection(Connection connection) { this.connection =
 * connection; }
 * 
 * public int boardInsert(BoardDto boardDto) throws Exception {
 * PreparedStatement pstmt = null; // 객체준비 // try {
 * 
 * } catch (Exception e) { // TODO: handle exception }
 * 
 * }
 * 
 * }
 */