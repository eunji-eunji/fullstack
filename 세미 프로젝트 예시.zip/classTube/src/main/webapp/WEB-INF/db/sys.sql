create user ctube identified by ctube123;

grant resource, connect, DBA to ctube;