package bank_test;

// 인터페이스
public interface Menu {
    void print();
    Menu next();
} 
